package com.egg.service;

import java.util.Arrays;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.egg.dao.BuyerRepository;
import com.egg.model.BuyerDetail;

//import com.egg.model.UserInfo;

@Service
public class BuyerService implements UserDetailsService {
@Autowired
private BuyerRepository br;
@Autowired
private BCryptPasswordEncoder bcryptEncoder;
	
	public BuyerDetail addBuyer(BuyerDetail buyer) {
		buyer.setPassword(bcryptEncoder.encode(buyer.getPassword()));
		return br.save(buyer);
				}
public List<BuyerDetail> getAllBuyer() {
		
		return br.findAll();
	}
public BuyerDetail findOne(String username) {
	// TODO Auto-generated method stub
	return br.findByBuyerName(username);
}
@Override
public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
	BuyerDetail user = br.findByBuyerName(username);
	if(user == null){
		throw new UsernameNotFoundException("Invalid username or password.");
	}
	return new org.springframework.security.core.userdetails.User(user.getBuyerName(), user.getPassword(), getAuthority());
}
private List<SimpleGrantedAuthority> getAuthority() {
	return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
}
}


