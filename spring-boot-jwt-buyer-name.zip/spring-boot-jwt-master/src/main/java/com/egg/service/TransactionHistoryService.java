package com.egg.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.dao.BuyerRepository;
import com.egg.dao.TransactionHistoryRepository;
import com.egg.model.TransactionHistory;



@Service
public class TransactionHistoryService {

	@Autowired
	private TransactionHistoryRepository transactionHistory;

	
	@Autowired
	private BuyerRepository buyer;
	
	public Optional<TransactionHistory> addTransaction(TransactionHistory transaction, Integer buyerId) {
		return buyer.findById(buyerId).map(buyer -> {
            transaction.setBuyer(buyer);
            return transactionHistory.save(transaction);
        });
	}
	
	
	
}
