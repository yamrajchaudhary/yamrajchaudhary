package com.egg.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.dao.BuyerRepository;
import com.egg.dao.CartRepository;
import com.egg.dao.PurchaseHistoryRepository;
import com.egg.dao.TransactionHistoryRepository;
import com.egg.model.BuyerDetail;
import com.egg.model.CartItem;
import com.egg.model.PurchaseHistory;
import com.egg.model.TransactionHistory;




@Service
public class CartService {
@Autowired
private CartRepository cr;
@Autowired
private BuyerRepository br;

@Autowired
private TransactionHistoryRepository transactionRepository;

@Autowired
private PurchaseHistoryRepository purchaseHistory;

private int totalprice=0;



	public Optional<CartItem> addCartItem(CartItem CartItems, Integer buyerId) {
		
		return br.findById(buyerId).map(buyer -> {
			
			CartItems.setBuyer(buyer);
			return cr.save(CartItems);	
			
		});
		
	}

	 public List<CartItem> searchAllCartItem(Integer buyerId){ 
		 List<CartItem>items = cr.findAllItem(buyerId); 
		 System.out.println(items);
		 return items; 
	
}
	 
		public String removeCartItems(Integer cartItemId) {
			cr.deleteById(cartItemId);
			return "Removed";	 
	 
	 
		} 
		public CartItem updateItems(CartItem item, Integer cartItemId) {
			Optional<CartItem> cartItem =cr.findById(cartItemId);
			if(cartItem.isPresent()) {
				CartItem newCartItem = cartItem.get();
				newCartItem.setQuantity(item.getQuantity());
				return cr.save(newCartItem);
			}
			return null;
}
		
		public String empty(Integer buyerId) {
			cr.deleteBuyers(buyerId);
			return "empty";	
		
		
		
		}	
		public String checkout(TransactionHistory transactionhistory,int ids) {
			 BuyerDetail buyerdetails = br.getOne(ids);
			 transactionhistory.setBuyer(buyerdetails);
			
			List<CartItem> cartItems= cr.getByBuyerId(ids);
			for(int i = 0; i < cartItems.size(); i++)
			{   
				CartItem cartitems =cartItems.get(i);
				totalprice=totalprice+cartitems.getPrice();
				
			}
			transactionhistory.setPrice(totalprice);
			transactionRepository.save(transactionhistory);
			System.out.println(cartItems);
			for(int i = 0; i < cartItems.size(); i++)
			{   
				CartItem cartitems =cartItems.get(i); 
				PurchaseHistory purchasehistory = new PurchaseHistory();
				
				purchasehistory.setBuyer(buyerdetails);
				int itemId=cartitems.getItemId();
				purchasehistory.setItemId(itemId);
				int numberOfItems = cartitems.getQuantity();
				purchasehistory.setNumberOfItems(numberOfItems);
				purchasehistory.setRemarks("good");
				purchasehistory.setTransaction(transactionhistory);
				purchaseHistory.save(purchasehistory);
				cr.delete(cartitems);
				
			}
			return "Success";
		}


	
		}
		
		
		
		
		
		
		
		
		
		
		
