package com.egg.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.egg.model.CartItem;
import com.egg.model.TransactionHistory;
import com.egg.service.CartService;









@CrossOrigin(origins = "*")
@RestController
public class CartController {
	
	@Autowired
	private CartService cs;
	
	@PostMapping(value="/{bid}/addcartitems",produces = "application/json")
	public CartItem addCartItem(@PathVariable("bid") Integer buyerId,@RequestBody CartItem CartItems) {
		Optional<CartItem> savedItem = cs.addCartItem(CartItems, buyerId);
		return savedItem.get();
	}
	
	@RequestMapping(value = "/{buyerId}/searchAllitem", method = RequestMethod.GET,produces = "application/json") 
	public List<CartItem> getAllCartItem(@PathVariable("buyerId") Integer buyerId) { 
		List<CartItem>Items = cs.searchAllCartItem(buyerId); 
		return Items; 
	
	}
	
	@RequestMapping(value = "/{cartItemId}/delete", method = RequestMethod.DELETE)
	public String deleteByCartItemId(@PathVariable(value = "cartItemId") Integer cartItemId) {
		String value = cs.removeCartItems(cartItemId);
		return value;
	
	}
	@RequestMapping(value = "/{cartItemId}/update", method = RequestMethod.PUT, produces = "application/json")
	public CartItem updateCartItems(@PathVariable(value = "cartItemId") Integer cartItemId,@RequestBody CartItem Item) {
		return cs.updateItems(Item, cartItemId);
	}
	
	@RequestMapping(value = "/{buyerId}/deleteAll", method = RequestMethod.DELETE)
	public String deleteAll(@PathVariable(value = "buyerId") Integer buyerId) {
		return cs.empty(buyerId);
	
	}
	@PostMapping("/checkout/{ids}") 
	public String checkout(@RequestBody TransactionHistory transactionhistory,@PathVariable("ids") Integer id) 
	{
		return cs.checkout(transactionhistory,id);
	}
	
}

	
	
	
	

