package com.hibernet;



import java.io.Serializable;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import org.hibernate.sql.ordering.antlr.Factory;





/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) 
    {
      
   Configuration configuration 	=new Configuration().configure();
    	

   StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder()
			.applySettings(configuration.getProperties());

       SessionFactory factory = configuration.buildSessionFactory(builder.build());

   Session session = factory.openSession();

    /* Product prod=new Product(1,"TV",38);
     
    session.beginTransaction();	
    	Serializable s= session.save(prod);
    	session.getTransaction().commit();*/
   
  /* Object p= session.load(Product.class,new Integer(1));
   Transaction txt= (Transaction) session.beginTransaction();
   Product o = (Product)p;
   o.setProdName("y");
   o.setProdquantity(12);
    txt.commit();	*/
    	
  /* Product produ = new Product(12,"yamraj don",345,567);
   session.beginTransaction();
   session.save(produ);
   session.getTransaction().commit();
    
    
    session.close();*/
    
  /*  
   String qry="select prod.productquantity FROM Product prod"; 
Query q=session.createQuery(qry);
	
	List<Product> ll=q.list() ;
	
    
    
    System.out.println(ll);*/
   
   
   				/*Query query = session.createQuery( "from Product produ where produ.prodId = :prodId ");
   				query.setParameter("prodId", 1001);
			  List<Product> list=query.list(); 
			  System.out.println(list); */
   
   
  /* Product p=new Product();
   p.setProdId(100); String hql = "from Product p where p.prodId = :prodId";
   List result = session.createQuery(hql).setProperties(p).list();
			  System.out.println(result);*/
	
   
  /* String hql = "from Product produ where produ.prodId =?";
	Query q = session.createQuery(hql);
	q.setParameter(0, 1001);                    
	List result = q.list();
	System.out.println(result);*/
   
   
   
   
   
   
   
   
    
    
    }
}
