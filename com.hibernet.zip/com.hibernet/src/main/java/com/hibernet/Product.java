package com.hibernet;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Table(name = "productdata")
@Entity
public class Product implements Serializable {
	@Id
	
	private int prodId;
	@Column(name="prodName")
	private String productName;
	@Column(name="prodquantity")
	private int productquantity;
	private int prodPrice;
public Product() {
		
}



public Product(int prodId, String prodName, int prodquantity, int prodPrice) {
	this.prodId = prodId;
	this.productName = prodName;
	this.productquantity = prodquantity;
	this.prodPrice = prodPrice;
}



public int getProdId() {
	return prodId;
}

public void setProdId(int prodId) {
	this.prodId = prodId;
}

public String getProdName() {
	return productName;
}

public void setProdName(String prodName) {
	this.productName = prodName;
}

public int getProdquantity() {
	return productquantity;
}

public void setProdquantity(int prodquantity) {
	this.productquantity = prodquantity;
}

public int getProdPrice() {
	return prodPrice;
}

public void setProdPrice(int prodPrice) {
	this.prodPrice = prodPrice;
}

@Override
public String toString() {
	return "Product [prodId=" + prodId + ", prodName=" + productName + ", prodquantity=" + productquantity + ", prodPrice="
			+ prodPrice + "]";
}




}
