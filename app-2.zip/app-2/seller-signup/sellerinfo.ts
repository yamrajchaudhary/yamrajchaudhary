export class info{

    username:String;
    password:String;
    companyName:String;
    gstIn:String;
    infoAboutCompany:String;
    postalAddress:String;
    website:String;
    email:String;
    contactNumber:number;





}






