import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';


import { FormsModule } from '@angular/forms';
import { GetAllItemsComponent } from './get-all-items/get-all-items.component';
import { BuyerSignUpComponent } from './buyer-sign-up/buyer-sign-up.component';
import { BuyerServiceService } from './buyer-service.service';
import { HttpClientModule } from '@angular/common/http';
@NgModule({
  declarations: [
    AppComponent,
    GetAllItemsComponent,
    BuyerSignUpComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [BuyerServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
