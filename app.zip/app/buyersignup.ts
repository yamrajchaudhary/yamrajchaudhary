
export class buyersignup {

    buyerId:number;
    buyerName:String;
    password:String;
    buyerEmail:String;
    mobileNumber:number;





}














