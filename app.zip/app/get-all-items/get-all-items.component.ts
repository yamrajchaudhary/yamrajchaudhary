import { Component, OnInit, Input } from '@angular/core';
import { BuyerServiceService } from '../buyer-service.service';
import { cartitems } from '../cartitem';

@Component({
  selector: 'app-get-all-items',
  templateUrl: './get-all-items.component.html',
  styleUrls: ['./get-all-items.component.css']
})
export class GetAllItemsComponent implements OnInit {
  cartitemss:cartitems[];
  cartitem1:cartitems;
  quantity:number=0;
  show:boolean = false;
  cartItemId:number;
  constructor(private dataService : BuyerServiceService) { }
  @Input() cartitem = new cartitems();
  ngOnInit(): void {
  }
  getallcartitems(){
    this.show =true;
    this.dataService.getallItems().subscribe(cartitems=>this.cartitemss=cartitems)
    
  } 
  addcartitems(){

    console.log("done");
    this.dataService.addcartitem(this.cartitemss).subscribe(cartitems=>this.cartitemss=cartitems)
  }
  
  
  increment(items:cartitems)
  {
    console.log("incrementing");
    items.quantity=items.quantity+1;
    this.cartItemId=items.cartItemId;
    this.cartitem1 = new cartitems();
    this.cartitem1.quantity=items.quantity;
    this.cartitem1.price=items.price;
    this.dataService.updatecartitems(this.cartitem1,this.cartItemId).subscribe(cartitems=>this.cartitemss=cartitems);
    console.log(items.price);
  }
  decrement(items:cartitems)
  {
    console.log("decrement");
    items.quantity=items.quantity-1;
    this.cartItemId=items.cartItemId;
    this.cartitem1 = new cartitems();
    this.cartitem1.quantity=items.quantity;
    this.cartitem1.price=items.price;
    this.dataService.updatecartitems(this.cartitem1,this.cartItemId).subscribe(cartitems=>this.cartitemss=cartitems);

  }
  deleteAll(items:cartitems)
  {
    console.log("in deleteall");
    console.log(items.cartItemId);
    this.dataService.deleteCartItems(items.cartItemId).subscribe(cartitems=>this.cartitemss=cartitems);
  }


}
