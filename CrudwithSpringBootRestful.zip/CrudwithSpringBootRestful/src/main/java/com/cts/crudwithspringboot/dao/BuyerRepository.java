package com.cts.crudwithspringboot.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.crudwithspringboot.entity.BuyerDetail;
@Repository
public interface BuyerRepository extends JpaRepository<BuyerDetail,Integer>{

	
	
}
