package com.cts.crudwithspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudwithspringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run( CrudwithspringbootApplication.class, args);
	}

}
