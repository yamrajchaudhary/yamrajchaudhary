package com.cts.crudwithspringboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.crudwithspringboot.dao.PurchaseHistoryRepository;
import com.cts.crudwithspringboot.entity.PurchaseHistory;




@Service
public class PurchaseHistoryService {

	
	
	@Autowired
	private PurchaseHistoryRepository pr;
	
	@Autowired
	private TransactionHistoryService ts;
	
	public PurchaseHistory addPurchaseHistory(PurchaseHistory purchasehistory){
		return pr.save(purchasehistory);
	}
	
	
	
}
