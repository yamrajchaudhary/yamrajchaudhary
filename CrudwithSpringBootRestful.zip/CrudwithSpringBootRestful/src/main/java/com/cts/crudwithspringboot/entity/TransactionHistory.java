package com.cts.crudwithspringboot.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
public class TransactionHistory {
	
@Id
	
	@GeneratedValue
	
	private Integer transactionId;
	@ManyToOne
	@JoinColumn(name = "buyerId")
	private BuyerDetail buyer;
	private String transactionType;
	@Temporal(TemporalType.DATE)
	private Date dateTime;
	private String remark;
	public TransactionHistory() {
		super();
		
	}
	public TransactionHistory(Integer transactionId, BuyerDetail buyer, String transactionType, Date dateTime,
			String remark) {
		super();
		this.transactionId = transactionId;
		this.buyer = buyer;
		this.transactionType = transactionType;
		this.dateTime = dateTime;
		this.remark = remark;
	}
	public Integer getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}
	public BuyerDetail getBuyer() {
		return buyer;
	}
	public void setBuyer(BuyerDetail buyer) {
		this.buyer = buyer;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public Date getDateTime() {
		return dateTime;
	}
	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	@Override
	public String toString() {
		return "transactionHistory [transactionId=" + transactionId + ", buyer=" + buyer + ", transactionType="
				+ transactionType + ", dateTime=" + dateTime + ", remark=" + remark + "]";
	}
	
	
	

}
