package com.cts.crudwithspringboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.crudwithspringboot.dao.BuyerRepository;
import com.cts.crudwithspringboot.entity.BuyerDetail;
@Service
public class BuyerService {
@Autowired
private BuyerRepository br;
	
	
	public BuyerDetail addBuyer(BuyerDetail buyer) {
		
		return br.save(buyer);
				
	}


	public List<BuyerDetail> getAllBuyer() {
		
		return br.findAll();
	}



		
	}


