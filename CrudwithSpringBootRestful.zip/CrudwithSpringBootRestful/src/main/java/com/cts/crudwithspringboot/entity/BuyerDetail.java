package com.cts.crudwithspringboot.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class BuyerDetail {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer buyerId;
	private String buyerName;
	private String password;
	private String buyerEmail;
	private Long MobileNumber;
	@JsonFormat(pattern = "dd/MM/yyyy")
	private Date createdDateTime;
	
	
	
	public BuyerDetail() {
	super();
}



	public BuyerDetail(Integer buyerId, String buyerName, String password, String buyerEmail, Long mobileNumber,
			Date createdDateTime) {
		super();
		this.buyerId = buyerId;
		this.buyerName = buyerName;
		this.password = password;
		this.buyerEmail = buyerEmail;
		MobileNumber = mobileNumber;
		this.createdDateTime = createdDateTime;
	}



	public Integer getBuyerId() {
		return buyerId;
	}



	public void setBuyerId(Integer buyerId) {
		this.buyerId = buyerId;
	}



	public String getBuyerName() {
		return buyerName;
	}



	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public String getBuyerEmail() {
		return buyerEmail;
	}



	public void setBuyerEmail(String buyerEmail) {
		this.buyerEmail = buyerEmail;
	}



	public Long getMobileNumber() {
		return MobileNumber;
	}



	public void setMobileNumber(Long mobileNumber) {
		MobileNumber = mobileNumber;
	}



	public Date getCreatedDateTime() {
		return createdDateTime;
	}



	public void setCreatedDateTime(Date createdDateTime) {
		this.createdDateTime = createdDateTime;
	}



	@Override
	public String toString() {
		return "buyerDetail [buyerId=" + buyerId + ", buyerName=" + buyerName + ", password=" + password
				+ ", buyerEmail=" + buyerEmail + ", MobileNumber=" + MobileNumber + ", createdDateTime="
				+ createdDateTime + "]";
	}
	
	
	
	
	
	
	
	
	
	
}