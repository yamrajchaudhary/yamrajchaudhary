package com.cts.crudwithspringboot.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;



@Entity
public class CartItem {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer cartItemId;
	private Integer itemId;
	private Integer quantity;
	@ManyToOne
	@JoinColumn(name = "buyerId")
	private BuyerDetail buyer;
	
	public CartItem() {
		
		
		super();
	}

	public CartItem(Integer cartItemId, Integer itemId, Integer quantity, BuyerDetail buyer) {
		super();
		this.cartItemId = cartItemId;
		this.itemId = itemId;
		this.quantity = quantity;
		this.buyer = buyer;
	}

	public Integer getCartItemId() {
		return cartItemId;
	}

	public void setCartItemId(Integer cartItemId) {
		this.cartItemId = cartItemId;
	}

	public Integer getItemId() {
		return itemId;
	}

	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public BuyerDetail getBuyer() {
		return buyer;
	}

	public void setBuyer(BuyerDetail buyer) {
		this.buyer = buyer;
	}

	@Override
	public String toString() {
		return "cartItem [cartItemId=" + cartItemId + ", itemId=" + itemId + ", quantity=" + quantity + ", buyer="
				+ buyer + "]";
	}
	
	
}
