package com.cts.crudwithspringboot.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonFormat;



@Entity
public class purchaseHistory {
	
	
	@Id
	@GeneratedValue
	private Integer purchaseHistoryId;
	@ManyToOne
	@JoinColumn(name = "buyerId")
	private BuyerDetail buyer;
	@ManyToOne
	@JoinColumn(name = "transactionId")
	private transactionHistory transaction;
	private Integer itemId;
	private Integer numberOfItems;
	@JsonFormat(pattern = "dd/MM/yyyy")
	private Date dateTime;
	private String remarks;
	public purchaseHistory() {
		super();
		// TODO Auto-generated constructor stub
	}
	public purchaseHistory(Integer purchaseHistoryId, BuyerDetail buyer, transactionHistory transaction, Integer itemId,
			Integer numberOfItems, Date dateTime, String remarks) {
		super();
		this.purchaseHistoryId = purchaseHistoryId;
		this.buyer = buyer;
		this.transaction = transaction;
		this.itemId = itemId;
		this.numberOfItems = numberOfItems;
		this.dateTime = dateTime;
		this.remarks = remarks;
	}
	public Integer getPurchaseHistoryId() {
		return purchaseHistoryId;
	}
	public void setPurchaseHistoryId(Integer purchaseHistoryId) {
		this.purchaseHistoryId = purchaseHistoryId;
	}
	public BuyerDetail getBuyer() {
		return buyer;
	}
	public void setBuyer(BuyerDetail buyer) {
		this.buyer = buyer;
	}
	public transactionHistory getTransaction() {
		return transaction;
	}
	public void setTransaction(transactionHistory transaction) {
		this.transaction = transaction;
	}
	public Integer getItemId() {
		return itemId;
	}
	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}
	public Integer getNumberOfItems() {
		return numberOfItems;
	}
	public void setNumberOfItems(Integer numberOfItems) {
		this.numberOfItems = numberOfItems;
	}
	public Date getDateTime() {
		return dateTime;
	}
	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	@Override
	public String toString() {
		return "purchaseHistory [purchaseHistoryId=" + purchaseHistoryId + ", buyer=" + buyer + ", transaction="
				+ transaction + ", itemId=" + itemId + ", numberOfItems=" + numberOfItems + ", dateTime=" + dateTime
				+ ", remarks=" + remarks + "]";
	}
	
	
	
	

}
