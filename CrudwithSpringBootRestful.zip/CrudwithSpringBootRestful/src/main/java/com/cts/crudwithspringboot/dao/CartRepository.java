package com.cts.crudwithspringboot.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.crudwithspringboot.entity.CartItem;
@Repository
public interface CartRepository extends JpaRepository<CartItem, Integer> {
	
	@Transactional
	@Modifying
	@Query(value = "SELECT * FROM cart_item cart WHERE cart.buyer_id = :buyerId", nativeQuery = true)
	public List<CartItem> findAllItem(@Param("buyerId")Integer buyerId); 
	@Query(value="SELECT * FROM cart_item cart WHERE cart.buyer_id = :buyerId", nativeQuery = true)
	public void deleteBuyers(@Param("buyerId")Integer buyerId);
	
	@Query(value = "DELETE FROM cart_item cart WHERE cart.buyer_id = :buyerId", nativeQuery = true)
	public void deleteByBuyersId(@Param("buyerId")Integer buyerId);
	
	
}
	
	
	

	

	

