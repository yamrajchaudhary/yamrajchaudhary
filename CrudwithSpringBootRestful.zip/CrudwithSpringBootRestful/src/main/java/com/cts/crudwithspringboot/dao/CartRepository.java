package com.cts.crudwithspringboot.dao;

import java.util.Optional;

import com.cts.crudwithspringboot.entity.CartItem;

public class CartRepository {

	
}
