package com.cts.crudwithspringboot.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.cts.crudwithspringboot.entity.BuyerDetail;
import com.cts.crudwithspringboot.service.BuyerService;
import com.cts.crudwithspringboot.service.TransactionHistoryService;



@RestController
public class BuyerController {

	@Autowired
	private BuyerService bs;
	
	
	@RequestMapping(value = "/addbuyer", method = RequestMethod.POST, produces = "application/json")
	public BuyerDetail addBuyer(@RequestBody BuyerDetail buyer)
	{
		
		BuyerDetail buyerDetail = bs.addBuyer(buyer);
		return buyerDetail;
}
	@GetMapping
	List<BuyerDetail> getAllBuyer() {
		return bs.getAllBuyer();
	}
	
	
	}
	
	
	
	
