package com.cts.crudwithspringboot.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cts.crudwithspringboot.dao.BuyerRepository;
import com.cts.crudwithspringboot.dao.TransactionHistoryRepository;

@Service
public class TransactionHistoryService {

	@Autowired
	private TransactionHistoryRepository TransactionHistory;

	
	@Autowired
	private BuyerRepository buyer;
	
	public Optional<TransactionHistory> addTransaction(TransactionHistory transaction, Integer buyerId) {
		return buyer.findById(buyerId).map(buyer -> {
            transaction.setBuyer(buyer);
            return TransactionHistory.save(transaction);
        });
	}
	
	
	
}
