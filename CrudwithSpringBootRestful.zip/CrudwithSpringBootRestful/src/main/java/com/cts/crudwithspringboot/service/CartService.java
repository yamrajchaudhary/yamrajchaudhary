package com.cts.crudwithspringboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;




import com.cts.crudwithspringboot.dao.BuyerRepository;
import com.cts.crudwithspringboot.dao.CartRepository;
import com.cts.crudwithspringboot.entity.CartItem;
@Service
public class CartService {
@Autowired
private CartRepository cr;
@Autowired
private BuyerRepository br;
	public Optional<CartItem> addCartItem(CartItem CartItems, Integer buyerId) {
		
		return br.findById(buyerId).map(buyer -> {
			
			CartItems.setBuyer(buyer);
			return cr.save(CartItems);	
			
		});
		
	}

	 public List<CartItem> searchAllCartItem(Integer buyerId){ 
		 List<CartItem>items = cr.findAllItem(buyerId); 
		 return items; 
	
}
	 
		public String removeCartItems(Integer cartItemId) {
			cr.deleteById(cartItemId);
			return "Removed";	 
	 
	 
		} 
		public CartItem updateItems(CartItem item, Integer cartItemId) {
			Optional<CartItem> cartItem =cr.findById(cartItemId);
			if(cartItem.isPresent()) {
				CartItem newCartItem = cartItem.get();
				newCartItem.setQuantity(item.getQuantity());
				return cr.save(newCartItem);
			}
			return null;
}
		
		public String empty(Integer buyerId) {
			cr.deleteBuyers(buyerId);
			return "empty";	
		
		
		
		}	
		
		public void checkout(Integer buyerId) {
			Double totalAmount = 0.00;
			TransactionHistory transaction = null;
			PurchaseHistory purchase = null;
			List<CartItems> cartItems = cartRepository.findAllCartItem(buyerId);
			for(CartItems items : cartItems) {
				Optional<Item> item = itemRepository.findById(items.getCartItemId());
				totalAmount += item.get().getPrice();
			}
			Optional<BuyerInfo> buyer = buyerRepository.findById(buyerId);
			transaction  = new TransactionHistory();
			transaction.setTransactionAmount(totalAmount);
			transaction.setBuyer(buyer.get());
			transaction.setTransactionType("debited");
			transaction.setRemarks("paid");
			
			transactionRepository.save(transaction);
			
			for(CartItems items : cartItems) {
				purchase = new PurchaseHistory();
				purchase.setBuyer(buyer.get());
				purchase.setTransaction(transaction);
				purchase.setItemId(items.getItemId());
				purchase.setRemarks("confirmed");
				purchase.setNumberOfItems(items.getQuantity());
				PurchaseHistory.save(purchase);
			}
		}
		
		
		
		
		
		
		
		
		
		
		
}