package com.cts.crudwithspringboot.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.crudwithspringboot.dao.CartRepository;
import com.cts.crudwithspringboot.entity.CartItem;
@Service
public class CartService {
@Autowired
private CartRepository cr;
	public Optional<CartItem> addCartItem(CartItem shoppingCartItem, Integer buyerId) {
		
		return cr.findById(buyerId).map(buyer -> {
			
			shoppingCartItem.setBuyerId(buyer);
			return cr.save(shoppingCartItem);	
			
			
		}
	}

}
