package com.cts.crudwithspringboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cts.crudwithspringboot.dao.BuyerRepository;
import com.cts.crudwithspringboot.dao.CartRepository;
import com.cts.crudwithspringboot.dao.PurchaseHistoryRepository;
import com.cts.crudwithspringboot.dao.TransactionHistoryRepository;
import com.cts.crudwithspringboot.entity.CartItem;
@Service
public class CartService {
@Autowired
private CartRepository cr;
@Autowired
private BuyerRepository br;

@Autowired
private TransactionHistoryRepository transactionRepository;

@Autowired
private PurchaseHistoryRepository purchaseHistory;





	public Optional<CartItem> addCartItem(CartItem CartItems, Integer buyerId) {
		
		return br.findById(buyerId).map(buyer -> {
			
			CartItems.setBuyer(buyer);
			return cr.save(CartItems);	
			
		});
		
	}

	 public List<CartItem> searchAllCartItem(Integer buyerId){ 
		 List<CartItem>items = cr.findAllItem(buyerId); 
		 return items; 
	
}
	 
		public String removeCartItems(Integer cartItemId) {
			cr.deleteById(cartItemId);
			return "Removed";	 
	 
	 
		} 
		public CartItem updateItems(CartItem item, Integer cartItemId) {
			Optional<CartItem> cartItem =cr.findById(cartItemId);
			if(cartItem.isPresent()) {
				CartItem newCartItem = cartItem.get();
				newCartItem.setQuantity(item.getQuantity());
				return cr.save(newCartItem);
			}
			return null;
}
		
		public String empty(Integer buyerId) {
			cr.deleteBuyers(buyerId);
			return "empty";	
		
		
		
		}	
		
	
		}
		
		
		
		
		
		
		
		
		
		
		
