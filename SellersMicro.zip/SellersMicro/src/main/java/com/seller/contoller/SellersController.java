package com.seller.contoller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.seller.entity.Sellers;
import com.seller.service.ItemsInfoService;
import com.seller.service.SellersService;



@RestController
@RequestMapping("/seller")
public class SellersController {
	
	@Autowired
	private SellersService sellersService;
	
	@Autowired
	private ItemsInfoService itemsInfoService;
	
	@PostMapping(value = "/seller", produces = "application/json")
	public Sellers addSellersInfo(@RequestBody Sellers sellers) {
		Sellers s = sellersService.addSellers(sellers);
		return s;
		
	}
	
	
}
