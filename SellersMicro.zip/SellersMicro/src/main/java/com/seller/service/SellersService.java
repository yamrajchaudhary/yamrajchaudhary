package com.seller.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.seller.entity.Sellers;
import com.seller.repository.ItemsInfoRepository;
import com.seller.repository.SellersRepository;

@Service
public class SellersService {

@Autowired
private SellersRepository sellersRepo;
@Autowired
private ItemsInfoRepository info;
public Sellers addSellers( Sellers sellers) {
	

	return sellersRepo.save(sellers);

}	


}
