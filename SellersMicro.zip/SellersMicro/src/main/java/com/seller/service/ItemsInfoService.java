package com.seller.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.seller.entity.ItemsInfo;
import com.seller.entity.Sellers;
import com.seller.repository.ItemsInfoRepository;
import com.seller.repository.SellersRepository;

@Service
public class ItemsInfoService {
	@Autowired
	private SellersRepository sellersRepo;
	@Autowired
private ItemsInfoRepository infoRepo;
	public Optional<ItemsInfo> addItem(ItemsInfo items, Integer sellersId) {
		
		return sellersRepo.findById(sellersId).map(sellersI ->{
				items.setSellers(sellersI);
				return infoRepo.save(items);
				
		}) ;
	}
	public List<ItemsInfo> getAllItems(Integer sellersId){
		return infoRepo.findBySellerId(sellersId);
	}
	public ItemsInfo modifyItem(ItemsInfo item, Integer itemId) {
		Optional<ItemsInfo> optionalItem = infoRepo.findById(itemId);
		if(optionalItem.isPresent()) {
			ItemsInfo updatedItem = optionalItem.get();
			updatedItem.setStock(item.getStock());
			updatedItem.setCategoriesId(item.getCategoriesId());
			updatedItem.setDescription(item.getDescription());
		
			updatedItem.setSubCategoriesId(item.getSubCategoriesId());
			updatedItem.setItemsName(item.getItemsName());
			updatedItem.setRemark(item.getRemark());
			
			return infoRepo.save(updatedItem);
		}
		
		return null;
	}
	public void removeItem(Integer sellersId, Integer itemsId) {
		infoRepo.deleteItemsInfoById(sellersId,itemsId);
	}
}
