package com.seller.service;

public class ItemsInfoService {

}
