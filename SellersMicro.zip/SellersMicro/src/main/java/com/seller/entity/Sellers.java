package com.seller.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;



@Entity
public class Sellers implements Serializable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer sellersId;
	private String username;
	private String password;
	private String companyName;
	private String gstIn;
	private String infoAboutCompany;
	private String postalAddress;
	private String website;
	private String email;
	private Long contactNumber;
	
	public Sellers() {	
	
	
	}

	public Sellers(Integer sellersId, String username, String password, String companyName, String gstIn,
			String infoAboutCompany, String postalAddress, String website, String email, Long contactNumber) {
		super();
		this.sellersId = sellersId;
		this.username = username;
		this.password = password;
		this.companyName = companyName;
		this.gstIn = gstIn;
		this.infoAboutCompany = infoAboutCompany;
		this.postalAddress = postalAddress;
		this.website = website;
		this.email = email;
		this.contactNumber = contactNumber;
	}

	public Integer getSellersId() {
		return sellersId;
	}

	public void setSellersId(Integer sellersId) {
		this.sellersId = sellersId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getGstIn() {
		return gstIn;
	}

	public void setGstIn(String gstIn) {
		this.gstIn = gstIn;
	}

	public String getInfoAboutCompany() {
		return infoAboutCompany;
	}

	public void setInfoAboutCompany(String infoAboutCompany) {
		this.infoAboutCompany = infoAboutCompany;
	}

	public String getPostalAddress() {
		return postalAddress;
	}

	public void setPostalAddress(String postalAddress) {
		this.postalAddress = postalAddress;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(Long contactNumber) {
		this.contactNumber = contactNumber;
	}

	@Override
	public String toString() {
		return "Sellers [sellersId=" + sellersId + ", username=" + username + ", password=" + password
				+ ", companyName=" + companyName + ", gstIn=" + gstIn + ", infoAboutCompany=" + infoAboutCompany
				+ ", postalAddress=" + postalAddress + ", website=" + website + ", email=" + email + ", contactNumber="
				+ contactNumber + "]";
	}
	
	
	
}