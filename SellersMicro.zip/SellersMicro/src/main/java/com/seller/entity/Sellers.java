package com.seller.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;





@Entity
public class Sellers implements Serializable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer sellersId;
	private String usernameInfo;
	private String passwordInfo;
	private String companyNameInfo;
	private String gstinInfo;
	private String infoAboutCompany;
	
	public Sellers() {
		
	}

	public Integer getSellersId() {
		return sellersId;
	}

	public void setSellersId(Integer sellersId) {
		this.sellersId = sellersId;
	}

	public String getUsernameInfo() {
		return usernameInfo;
	}

	public void setUsernameInfo(String usernameInfo) {
		this.usernameInfo = usernameInfo;
	}

	public String getPasswordInfo() {
		return passwordInfo;
	}

	public void setPasswordInfo(String passwordInfo) {
		this.passwordInfo = passwordInfo;
	}

	public String getCompanyNameInfo() {
		return companyNameInfo;
	}

	public void setCompanyNameInfo(String companyNameInfo) {
		this.companyNameInfo = companyNameInfo;
	}

	public String getGstinInfo() {
		return gstinInfo;
	}

	public void setGstinInfo(String gstinInfo) {
		this.gstinInfo = gstinInfo;
	}

	public String getInfoAboutCompany() {
		return infoAboutCompany;
	}

	public void setInfoAboutCompany(String infoAboutCompany) {
		this.infoAboutCompany = infoAboutCompany;
	}

	public Sellers(Integer sellersId, String usernameInfo, String passwordInfo, String companyNameInfo,
			String gstinInfo, String infoAboutCompany) {
		super();
		this.sellersId = sellersId;
		this.usernameInfo = usernameInfo;
		this.passwordInfo = passwordInfo;
		this.companyNameInfo = companyNameInfo;
		this.gstinInfo = gstinInfo;
		this.infoAboutCompany = infoAboutCompany;
	}

	@Override
	public String toString() {
		return "Sellers [sellersId=" + sellersId + ", usernameInfo=" + usernameInfo + ", passwordInfo=" + passwordInfo
				+ ", companyNameInfo=" + companyNameInfo + ", gstinInfo=" + gstinInfo + ", infoAboutCompany="
				+ infoAboutCompany + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
