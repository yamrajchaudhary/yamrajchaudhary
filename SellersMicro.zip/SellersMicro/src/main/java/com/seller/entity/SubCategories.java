package com.seller.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;



@Entity
public class SubCategories implements Serializable{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer subCategoriesId;
	private String subCategoriesName;
	@ManyToOne
	@JoinColumn(name = "categoriesId")
	private Categories categories;
	private String briefInfo;
	private Integer gst;
	public SubCategories() {
			
	}
	public Integer getSubCategoriesId() {
		return subCategoriesId;
	}
	public void setSubCategoriesId(Integer subCategoriesId) {
		this.subCategoriesId = subCategoriesId;
	}
	public String getSubCategoriesName() {
		return subCategoriesName;
	}
	public void setSubCategoriesName(String subCategoriesName) {
		this.subCategoriesName = subCategoriesName;
	}
	public Categories getCategories() {
		return categories;
	}
	public void setCategories(Categories categories) {
		this.categories = categories;
	}
	public String getBriefInfo() {
		return briefInfo;
	}
	public void setBriefInfo(String briefInfo) {
		this.briefInfo = briefInfo;
	}
	public Integer getGst() {
		return gst;
	}
	public void setGst(Integer gst) {
		this.gst = gst;
	}
	public SubCategories(Integer subCategoriesId, String subCategoriesName, Categories categories, String briefInfo,
			Integer gst) {
		super();
		this.subCategoriesId = subCategoriesId;
		this.subCategoriesName = subCategoriesName;
		this.categories = categories;
		this.briefInfo = briefInfo;
		this.gst = gst;
	}
	@Override
	public String toString() {
		return "SubCategories [subCategoriesId=" + subCategoriesId + ", subCategoriesName=" + subCategoriesName
				+ ", categories=" + categories + ", briefInfo=" + briefInfo + ", gst=" + gst + "]";
	}
	
	
	
	
	
	
	
}
