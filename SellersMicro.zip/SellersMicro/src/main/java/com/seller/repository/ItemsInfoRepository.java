package com.seller.repository;

public interface ItemsInfoRepository {

}
