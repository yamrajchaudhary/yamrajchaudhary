package com.seller.repository;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.seller.entity.ItemsInfo;
import com.seller.entity.Sellers;
@Repository
public interface ItemsInfoRepository extends JpaRepository<ItemsInfo, Integer>{

	
	@Query(value="SELECT * FROM items_info WHERE items_info.sellers_id= :sellers_id",nativeQuery=true)
	List<ItemsInfo> findBySellerId(@Param(value="sellers_id") Integer sellers_id);
	@Query(value="SELECT * FROM items_info WHERE items_info.sellers_id= ?1",nativeQuery=true)
	public void deleteItemsInfoById(@Param("sellersId") Integer sellerId,@Param("itemsId") Integer itemsId); 


}
