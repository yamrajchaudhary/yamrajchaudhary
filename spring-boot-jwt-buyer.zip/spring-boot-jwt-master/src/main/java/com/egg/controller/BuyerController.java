package com.egg.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.egg.model.BuyerDetail;
import com.egg.service.BuyerService;





@CrossOrigin(origins = "*")
@RestController
public class BuyerController {

	@Autowired
	private BuyerService bs;
	
	
	@RequestMapping(value = "/addbuyer", method = RequestMethod.POST, produces = "application/json")
	public BuyerDetail addBuyer(@RequestBody BuyerDetail buyer)
	{
		System.out.println(buyer);
		BuyerDetail buyerDetail = bs.addBuyer(buyer);
		return buyerDetail;
}
	@GetMapping
	List<BuyerDetail> getAllBuyer() {
		return bs.getAllBuyer();
	}
	
	
	}
	
	
	
	
