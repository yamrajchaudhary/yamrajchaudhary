package com.egg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.dao.PurchaseHistoryRepository;
import com.egg.model.PurchaseHistory;


@Service
public class PurchaseHistoryService {

	
	
	@Autowired
	private PurchaseHistoryRepository pr;
	
	@Autowired
	private TransactionHistoryService ts;
	
	public PurchaseHistory addPurchaseHistory(PurchaseHistory purchasehistory){
		return pr.save(purchasehistory);
	}
	
	
	
}
