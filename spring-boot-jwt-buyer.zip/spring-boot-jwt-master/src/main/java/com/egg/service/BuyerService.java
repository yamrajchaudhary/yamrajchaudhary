package com.egg.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.dao.BuyerRepository;
import com.egg.model.BuyerDetail;

@Service
public class BuyerService {
@Autowired
private BuyerRepository br;
	
	public BuyerDetail addBuyer(BuyerDetail buyer) {
		
		return br.save(buyer);
				}
public List<BuyerDetail> getAllBuyer() {
		
		return br.findAll();
	}
}


