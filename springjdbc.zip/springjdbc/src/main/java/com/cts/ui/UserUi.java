package com.cts.ui;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;

import com.cts.model.User;
import com.cts.service.UserService;

public class UserUi {
	@Autowired
	private User user;
	@Autowired
	private UserService userService;
	
	public static void main(String args[]) {
		
		Integer userID;
		String  userName;
		Integer userAge;
		Long userMob;
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Your Information:");
		System.out.println("Enter your Name >");
		userName = scan.next();
		System.out.println("Enter your Age >");
		userAge = scan.nextInt();
		System.out.println("Enter your Mobile Number >");
		userMob = scan.nextLong();
		
		
	}
}
