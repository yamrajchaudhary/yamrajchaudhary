package com.cts.dao;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.cts.model.User;

@Repository
public class UserDao extends JdbcDaoSupport{
	
	/*@Autowired
	private DataSource ds;
	private JdbcTemplate jdbc;

	@Autowired
	public void setDs(DataSource ds) {
		this.ds=ds;
		jdbc=new JdbcTemplate(this.ds);
	}*/
	//Either use this or use JdbcDaoSupport
	//We also have to create bean in xml for this class.
	
	/*<bean id="userdao" class="com.cts.dao.UserDao">
	<property name="datasource" ref="ds"></property>
	</bean>*/

	public int addUser(User user){
		int storedStatus=getJdbcTemplate().update("INSERT INTO user values(?,?,?,?)",new Object[]{user.getUserID(),user.getUserName(),user.getUserAge(),user.getUserMobile()});
		System.out.println(storedStatus);
		return user.getUserID();
	}
}
