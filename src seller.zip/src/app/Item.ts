export class Itemsearch1
{
    prodname:String;
}