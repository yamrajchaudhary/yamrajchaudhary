export class Itemlist
{   
    itemsName:String;
    price:number;
    stock:number;
    description:String;
    remark:String;
    }













  