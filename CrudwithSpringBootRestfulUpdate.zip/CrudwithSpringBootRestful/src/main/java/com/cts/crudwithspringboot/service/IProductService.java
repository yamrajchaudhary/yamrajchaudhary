package com.cts.crudwithspringboot.service;

import java.util.List;
import java.util.Optional;

import com.cts.crudwithspringboot.model.Product;

public interface IProductService {
	public List<Product> getall();
	public Optional<Product> getById(Integer id);
	public Integer updateProduct(Integer id, Product product);
	public void deleteById(Integer id);
	public Integer addProduct(Product product);
}
