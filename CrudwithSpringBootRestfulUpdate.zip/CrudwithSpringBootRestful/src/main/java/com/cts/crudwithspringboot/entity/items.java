package com.cts.crudwithspringboot.entity;

public class items {

}
