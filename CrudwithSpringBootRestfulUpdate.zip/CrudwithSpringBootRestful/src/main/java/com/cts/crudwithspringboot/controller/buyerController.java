package com.cts.crudwithspringboot.controller;

public class buyerController {

}
