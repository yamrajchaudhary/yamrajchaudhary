import { Component, OnInit, Input } from '@angular/core';
import { BuyerServiceService } from '../buyer-service.service';
import { cartitems } from '../cartitem';

@Component({
  selector: 'app-get-all-items',
  templateUrl: './get-all-items.component.html',
  styleUrls: ['./get-all-items.component.css']
})
export class GetAllItemsComponent implements OnInit {
  cartitemss:cartitems[];
  show:boolean = false;
  constructor(private dataService : BuyerServiceService) { }
  @Input() cartitem = new cartitems();
  ngOnInit(): void {
  }
  getallcartitems(){
    this.show =true;
    this.dataService.getallItems().subscribe(cartitems=>this.cartitemss=cartitems)
    
  } 
  addcartitems(){

    console.log("done");
    this.dataService.addcartitem(this.cartitemss).subscribe(cartitems=>this.cartitemss=cartitems)
  }
}
