import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BuyerServiceService {
  private baseUrl1 = 'http://localhost:8081/addbuyer';
  private baseurl7 = 'http://localhost:8081/2/searchAllitem'; //seller
  private baseurl6 = 'http://localhost:8081/2/addcartitems'; //buyer
  constructor(private http: HttpClient) { }
  buyerssignup(buyersignup:Object):Observable<any>
  {   
      console.log("in buyer method");
      console.log(buyersignup);
      
      return this.http.post(`${this.baseUrl1}`,buyersignup);
  }
  //buyer
  getallItems():Observable<any>
  {
    console.log("In Service");
    return this.http.get(`${this.baseurl7}`);
  }
  addcartitem(cartitems:object):Observable<any>
  {
    console.log(cartitems);
    return this.http.post(`${this.baseurl6}`,cartitems);
  }
 
 


}
