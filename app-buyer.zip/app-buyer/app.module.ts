import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';


import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { GetAllItemsComponent } from './get-all-items/get-all-items.component';
import { BuyerSignUpComponent } from './buyer-sign-up/buyer-sign-up.component';
import { BuyerServiceService } from './buyer-service.service';
import { HttpClientModule } from '@angular/common/http';
import { CheckoutComponent } from './checkout/checkout.component';
import { LoginBuyerComponent } from './login-buyer/login-buyer.component';

@NgModule({
  declarations: [
    AppComponent,
    GetAllItemsComponent,
    BuyerSignUpComponent,
    CheckoutComponent,
    LoginBuyerComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [BuyerServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
