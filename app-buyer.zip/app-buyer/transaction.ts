export class transactions {
    transactionType:String;
    remark:String;

    ids:number;




}