package com.cts.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.Product;
import com.cts.services.ProductServices;

@RestController
public class ProductController {

	@Autowired
	ProductServices prodservice;

	@RequestMapping(value = "/product", method = RequestMethod.POST, produces = "application/json")
	public int addProduct(@RequestBody Product product) {
		//Product product = new Product(prodId, prodName, prodQuantity, prodprice);
		return prodservice.addProduct(product);
	}

	//Get By ID
	@RequestMapping(value="/getbyid/{prodId}",method=RequestMethod.GET)
	public ResponseEntity<Product> getById(@PathVariable("prodId") int prodId) {
		Product product = prodservice.getById(prodId);
		if(product == null) {
			return new ResponseEntity<Product>(HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<Product>(product,HttpStatus.OK);
	}
}
